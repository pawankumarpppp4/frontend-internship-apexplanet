
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.querySelector('.nav-toggle');
            const navMenu = document.querySelector('nav ul');
            
            if (navToggle && navMenu) {
                navToggle.addEventListener('click', function(event) {
                    event.stopPropagation();
                    const isExpanded = this.getAttribute('aria-expanded') === 'true';
                    this.setAttribute('aria-expanded', !isExpanded);
                    navMenu.classList.toggle('active');
                });
                
                navMenu.querySelectorAll('a').forEach(link => {
                    link.addEventListener('click', () => {
                        navMenu.classList.remove('active');
                        navToggle.setAttribute('aria-expanded', 'false');
                    });
                });
            }
            
            loadProducts();
            setupCart();
            setupSearch();
            registerServiceWorker();
        });
        
        function loadProducts(filteredProducts) {
            const productGrid = document.getElementById('product-grid');
            if (!productGrid) return;
            
            const products = [
                { id: 1, name: 'Bamboo Toothbrush', price: 249, rating: 4.5, description: 'Eco-friendly bamboo toothbrush with biodegradable bristles', image: 'https://i.pinimg.com/736x/d4/1e/98/d41e981850303d1d01a91e2b622d2cee.jpg' },
                { id: 2, name: 'Reusable Water Bottle', price: 1099, rating: 4.8, description: 'Stainless steel water bottle, keeps drinks cold for 24 hours', image: 'https://i.pinimg.com/736x/9c/c7/06/9cc706bb5ff3178bf7018a51ff6ad9cd.jpg' },
                { id: 3, name: 'Organic Cotton Tote', price: 749, rating: 4.3, description: 'Durable organic cotton tote bag for shopping', image: 'https://i.pinimg.com/736x/f6/65/a5/f665a56d4054edbf4eccee1ca2096181.jpg' },
                { id: 4, name: 'Beeswax Wraps', price: 839, rating: 4.6, description: 'Set of 3 reusable beeswax food wraps', image: 'https://i.pinimg.com/736x/01/cc/de/01ccde3b7fdf68978ba23cf8a38dc2bb.jpg' },
                { id: 5, name: 'Eco-Friendly Notebook', price: 299, rating: 4.2, description: 'Recycled paper notebook for sustainable writing', image: 'https://i.pinimg.com/736x/be/4d/93/be4d93c4ed6386038a4aa740825fde05.jpg' },
                { id: 6, name: 'Bamboo Cutlery Set', price: 499, rating: 4.4, description: 'Portable bamboo cutlery set with cloth pouch', image: 'https://i.pinimg.com/736x/ce/0e/ab/ce0eab394782d33b958e78714e3b60b6.jpg' },
                { id: 7, name: 'Organic Cotton Bedsheet', price: 2499, rating: 4.7, description: 'Soft, breathable organic cotton bedsheet', image: 'https://i.pinimg.com/736x/1e/ae/eb/1eaeeba76d63f794f9757262c9bbf5cb.jpg' },
                { id: 8, name: 'Reusable Coffee Cup', price: 899, rating: 4.5, description: 'BPA-free reusable coffee cup with silicone lid', image: 'https://i.pinimg.com/736x/db/90/1f/db901f585d7cf804a8f4943248f52509.jpg' },
                { id: 9, name: 'Eco Laundry Detergent', price: 599, rating: 4.3, description: 'Biodegradable, chemical-free laundry detergent', image: 'https://i.pinimg.com/736x/ac/9e/1f/ac9e1ff68eb1aee7789ac087d8535b92.jpg' },
                { id: 10, name: 'Solar Charger', price: 2999, rating: 4.6, description: 'Portable solar-powered phone charger', image: 'https://i.pinimg.com/736x/7f/f2/57/7ff257cca19d11cf978094c8d575ceb3.jpg' },
                { id: 11, name: 'Organic Cotton Saree', price: 3499, rating: 4.8, description: 'Handwoven organic cotton saree with natural dyes', image: 'https://i.pinimg.com/736x/f7/c9/26/f7c926ad27a5024380188e0cd365751d.jpg' },
                { id: 12, name: 'Bamboo Straw Set', price: 199, rating: 4.2, description: 'Set of 6 reusable bamboo straws with cleaning brush', image: 'https://i.pinimg.com/736x/c5/df/11/c5df11e6c517e3cc89fbc6513e9a2210.jpg' },
                { id: 13, name: 'Eco-Friendly Yoga Mat', price: 1599, rating: 4.5, description: 'Cork and natural rubber yoga mat', image: 'https://i.pinimg.com/736x/ae/5e/da/ae5edaf3346cd44d7a322c6b5c41b911.jpg' },
                { id: 14, name: 'Recycled Plastic Planter', price: 399, rating: 4.3, description: 'Planter made from recycled plastic bottles', image: 'https://i.pinimg.com/736x/6a/55/d4/6a55d40f38749a7159afd882f81bf688.jpg' },
                { id: 15, name: 'Organic Tea Blend', price: 499, rating: 4.7, description: 'Organic green tea blend from Darjeeling', image: 'https://i.pinimg.com/736x/20/ba/6f/20ba6f30d4b84153d1eacdbd81583eab.jpg' },
                { id: 16, name: 'Hemp Backpack', price: 2499, rating: 4.6, description: 'Durable backpack made from sustainable hemp', image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62' },
                { id: 17, name: 'Eco Dish Scrubber', price: 149, rating: 4.1, description: 'Coconut coir dish scrubber, biodegradable', image: 'https://i.pinimg.com/736x/23/83/54/238354894931ddeaa2308f375ae6fa58.jpg' },
                { id: 18, name: 'Reusable Face Mask', price: 299, rating: 4.4, description: 'Organic cotton reusable face mask', image: 'https://i.pinimg.com/736x/59/53/a7/5953a7316ee5a8b82b333d7640190eba.jpg' },
                { id: 19, name: 'Bamboo Sunglasses', price: 1999, rating: 4.5, description: 'Sunglasses with bamboo frames and polarized lenses', image: 'https://i.pinimg.com/736x/4e/f5/71/4ef5715ff055da55a1a6cbe35e518998.jpg' },
                { id: 20, name: 'Eco-Friendly Lunch Box', price: 799, rating: 4.3, description: 'Stainless steel lunch box with bamboo lid', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 21, name: 'Organic Jute Rug', price: 2999, rating: 4.6, description: 'Handwoven jute rug for eco-friendly decor', image: 'https://i.pinimg.com/736x/e5/75/88/e57588d0854db2048a1d305d1353093e.jpg' },
                { id: 22, name: 'Reusable Produce Bags', price: 349, rating: 4.2, description: 'Set of 5 organic cotton produce bags', image: 'https://images.unsplash.com/photo-1580870069867-74c57ee1bb07' },
                { id: 23, name: 'Eco-Friendly Pen', price: 99, rating: 4.0, description: 'Pen made from recycled paper and bamboo', image: 'https://images.unsplash.com/photo-1516961642265-531546e84af2' },
                { id: 24, name: 'Organic Soap Bar', price: 199, rating: 4.5, description: 'Natural soap with neem and turmeric', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 25, name: 'Bamboo Laptop Stand', price: 1499, rating: 4.4, description: 'Ergonomic bamboo laptop stand', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 26, name: 'Recycled Glass Tumbler', price: 499, rating: 4.3, description: 'Set of 2 tumblers made from recycled glass', image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8' },
                { id: 27, name: 'Eco-Friendly Shampoo Bar', price: 399, rating: 4.6, description: 'Zero-waste shampoo bar with natural ingredients', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 28, name: 'Organic Cotton Kurta', price: 1899, rating: 4.7, description: 'Handwoven kurta with natural dyes', image: 'https://i.pinimg.com/736x/2e/71/a5/2e71a5a22937f2d046c2918eb49aa697.jpg' },
                { id: 29, name: 'Bamboo Kitchen Towels', price: 599, rating: 4.4, description: 'Set of 3 absorbent bamboo kitchen towels', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 30, name: 'Eco-Friendly Coasters', price: 249, rating: 4.2, description: 'Set of 4 coasters made from recycled wood', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 31, name: 'Organic Spices Set', price: 699, rating: 4.5, description: 'Set of 5 organic spices from Kerala', image: 'https://images.unsplash.com/photo-1513040808856-9a6c2b1b5c53' },
                { id: 32, name: 'Reusable Silicone Bags', price: 799, rating: 4.3, description: 'Set of 3 reusable silicone food storage bags', image: 'https://images.unsplash.com/photo-1621335673328-76ef5ce7d845' },
                { id: 33, name: 'Eco-Friendly Umbrella', price: 999, rating: 4.4, description: 'Umbrella made from recycled PET fabric', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 34, name: 'Bamboo Phone Case', price: 599, rating: 4.2, description: 'Biodegradable bamboo phone case', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 35, name: 'Organic Cotton Scarf', price: 799, rating: 4.5, description: 'Handwoven organic cotton scarf', image: 'https://images.unsplash.com/photo-1599487489922-398c8e2b7e3c' },
                { id: 36, name: 'Eco-Friendly Candle', price: 499, rating: 4.3, description: 'Soy wax candle with natural fragrance', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 37, name: 'Recycled Paper Journal', price: 349, rating: 4.2, description: 'Journal made from 100% recycled paper', image: 'https://images.unsplash.com/photo-1516961642265-531546e84af2' },
                { id: 38, name: 'Bamboo Hairbrush', price: 399, rating: 4.4, description: 'Eco-friendly bamboo hairbrush with natural bristles', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 39, name: 'Organic Cotton Socks', price: 299, rating: 4.3, description: 'Set of 3 pairs of organic cotton socks', image: 'https://images.unsplash.com/photo-1599487489922-398c8e2b7e3c' },
                { id: 40, name: 'Eco-Friendly Dish Soap', price: 249, rating: 4.1, description: 'Biodegradable dish soap with natural ingredients', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 41, name: 'Recycled Plastic Bottle', price: 499, rating: 4.4, description: 'Bottle made from recycled plastic', image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8' },
                { id: 42, name: 'Organic Cotton Towel', price: 999, rating: 4.6, description: 'Soft organic cotton bath towel', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 43, name: 'Eco-Friendly Toothpaste', price: 199, rating: 4.2, description: 'Natural toothpaste in recyclable packaging', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 44, name: 'Bamboo Soap Dish', price: 249, rating: 4.3, description: 'Bamboo soap dish for zero-waste bathroom', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 45, name: 'Organic Coffee Beans', price: 599, rating: 4.7, description: 'Organic coffee beans from Coorg', image: 'https://images.unsplash.com/photo-1513040808856-9a6c2b1b5c53' },
                { id: 46, name: 'Reusable Menstrual Pads', price: 499, rating: 4.5, description: 'Set of 3 reusable organic cotton menstrual pads', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 47, name: 'Eco-Friendly Deodorant', price: 349, rating: 4.3, description: 'Natural deodorant in compostable packaging', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 48, name: 'Bamboo Desk Organizer', price: 799, rating: 4.4, description: 'Bamboo organizer for eco-friendly workspace', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 49, name: 'Organic Cotton Apron', price: 699, rating: 4.5, description: 'Durable organic cotton apron for cooking', image: 'https://images.unsplash.com/photo-1599487489922-398c8e2b7e3c' },
                { id: 50, name: 'Eco-Friendly Razor', price: 499, rating: 4.2, description: 'Bamboo handle safety razor', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 51, name: 'Recycled Plastic Mat', price: 999, rating: 4.4, description: 'Floor mat made from recycled plastic', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 52, name: 'Organic Cotton Pillowcase', price: 499, rating: 4.6, description: 'Set of 2 organic cotton pillowcases', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 53, name: 'Eco-Friendly Lip Balm', price: 149, rating: 4.3, description: 'Natural lip balm in recyclable tin', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 54, name: 'Bamboo Water Bottle', price: 1299, rating: 4.5, description: 'Insulated bamboo water bottle', image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8' },
                { id: 55, name: 'Organic Cotton Handkerchief', price: 199, rating: 4.2, description: 'Set of 3 organic cotton handkerchiefs', image: 'https://images.unsplash.com/photo-1599487489922-398c8e2b7e3c' },
                { id: 56, name: 'Eco-Friendly Dish Brush', price: 249, rating: 4.3, description: 'Bamboo handle dish brush with natural bristles', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 57, name: 'Organic Herbal Tea', price: 399, rating: 4.6, description: 'Organic herbal tea blend from Assam', image: 'https://images.unsplash.com/photo-1513040808856-9a6c2b1b5c53' },
                { id: 58, name: 'Recycled Paper Calendar', price: 299, rating: 4.2, description: 'Eco-friendly desk calendar from recycled paper', image: 'https://images.unsplash.com/photo-1516961642265-531546e84af2' },
                { id: 59, name: 'Bamboo Wall Shelf', price: 1499, rating: 4.5, description: 'Sustainable bamboo wall shelf for home decor', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 60, name: 'Organic Cotton Shirt', price: 1599, rating: 4.7, description: 'Handwoven organic cotton shirt', image: 'https://images.unsplash.com/photo-1599487489922-398c8e2b7e3c' },
                { id: 61, name: 'Eco-Friendly Body Lotion', price: 499, rating: 4.3, description: 'Natural body lotion in recyclable packaging', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 62, name: 'Bamboo Serving Tray', price: 799, rating: 4.4, description: 'Eco-friendly bamboo serving tray', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 63, name: 'Organic Cotton Napkins', price: 399, rating: 4.5, description: 'Set of 4 organic cotton napkins', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 64, name: 'Eco-Friendly Face Cream', price: 599, rating: 4.3, description: 'Natural face cream with organic ingredients', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 65, name: 'Bamboo Cutting Board', price: 699, rating: 4.4, description: 'Durable bamboo cutting board for kitchen', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 66, name: 'Organic Cotton Blanket', price: 2499, rating: 4.7, description: 'Cozy organic cotton blanket', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 67, name: 'Eco-Friendly Hand Soap', price: 249, rating: 4.2, description: 'Natural hand soap in recyclable bottle', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 68, name: 'Bamboo Photo Frame', price: 499, rating: 4.3, description: 'Eco-friendly bamboo photo frame', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 69, name: 'Organic Cotton Curtains', price: 1999, rating: 4.6, description: 'Set of 2 organic cotton curtains', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 70, name: 'Eco-Friendly Body Wash', price: 399, rating: 4.4, description: 'Natural body wash in compostable packaging', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 71, name: 'Bamboo Coaster Set', price: 349, rating: 4.3, description: 'Set of 6 bamboo coasters', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 72, name: 'Organic Cotton Duvet', price: 3499, rating: 4.7, description: 'Organic cotton duvet cover', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 73, name: 'Eco-Friendly Sunscreen', price: 499, rating: 4.5, description: 'Natural sunscreen with eco-friendly packaging', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 74, name: 'Bamboo Salad Bowl', price: 799, rating: 4.4, description: 'Large bamboo salad bowl for eco-friendly dining', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 75, name: 'Organic Cotton Tablecloth', price: 1299, rating: 4.6, description: 'Handwoven organic cotton tablecloth', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 76, name: 'Eco-Friendly Shaving Cream', price: 349, rating: 4.3, description: 'Natural shaving cream in recyclable tin', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 77, name: 'Bamboo Spice Rack', price: 999, rating: 4.4, description: 'Eco-friendly bamboo spice rack', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 78, name: 'Organic Cotton Shawl', price: 999, rating: 4.7, description: 'Handwoven organic cotton shawl with natural dyes', image: 'https://images.unsplash.com/photo-1599487489922-398c8e2b7e3c' },
                { id: 79, name: 'Eco-Friendly Tooth Powder', price: 199, rating: 4.2, description: 'Natural tooth powder in recyclable jar', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 80, name: 'Bamboo Placemats', price: 499, rating: 4.3, description: 'Set of 4 bamboo placemats for dining', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 81, name: 'Organic Cotton Bathrobe', price: 1999, rating: 4.6, description: 'Soft organic cotton bathrobe', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 82, name: 'Eco-Friendly Face Wash', price: 399, rating: 4.4, description: 'Natural face wash in recyclable bottle', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 83, name: 'Bamboo Keychain', price: 149, rating: 4.1, description: 'Eco-friendly bamboo keychain', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c' },
                { id: 84, name: 'Organic Cotton Slippers', price: 799, rating: 4.5, description: 'Comfortable organic cotton slippers', image: 'https://images.unsplash.com/photo-1599487489922-398c8e2b7e3c' },
                { id: 85, name: 'Eco-Friendly Hand Cream', price: 299, rating: 4.3, description: 'Natural hand cream in compostable tube', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 86, name: 'Bamboo Wine Rack', price: 1299, rating: 4.4, description: 'Eco-friendly bamboo wine rack', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 87, name: 'Organic Cotton Face Towel', price: 249, rating: 4.2, description: 'Soft organic cotton face towel', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 88, name: 'Eco-Friendly Body Scrub', price: 499, rating: 4.5, description: 'Natural body scrub with organic ingredients', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 89, name: 'Bamboo Napkin Holder', price: 349, rating: 4.3, description: 'Eco-friendly bamboo napkin holder', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 90, name: 'Organic Cotton Pajamas', price: 1799, rating: 4.6, description: 'Comfortable organic cotton pajamas', image: 'https://images.unsplash.com/photo-1599487489922-398c8e2b7e3c' },
                { id: 91, name: 'Eco-Friendly Conditioner', price: 399, rating: 4.4, description: 'Natural conditioner in recyclable bottle', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 92, name: 'Bamboo Magazine Rack', price: 999, rating: 4.3, description: 'Eco-friendly bamboo magazine rack', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 93, name: 'Organic Cotton Table Runner', price: 599, rating: 4.5, description: 'Handwoven organic cotton table runner', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 94, name: 'Eco-Friendly Moisturizer', price: 499, rating: 4.4, description: 'Natural moisturizer in recyclable jar', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 95, name: 'Bamboo Laundry Basket', price: 1499, rating: 4.6, description: 'Eco-friendly bamboo laundry basket', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 96, name: 'Organic Cotton Cushion Cover', price: 399, rating: 4.3, description: 'Organic cotton cushion cover for decor', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 97, name: 'Eco-Friendly Hair Oil', price: 349, rating: 4.4, description: 'Natural hair oil in recyclable bottle', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 98, name: 'Bamboo Shoe Rack', price: 1299, rating: 4.5, description: 'Eco-friendly bamboo shoe rack', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 99, name: 'Organic Cotton Bedspread', price: 2999, rating: 4.7, description: 'Handwoven organic cotton bedspread', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' },
                { id: 100, name: 'Eco-Friendly Lipstick', price: 499, rating: 4.4, description: 'Natural lipstick in compostable packaging', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 101, name: 'Bamboo Wall Clock', price: 999, rating: 4.3, description: 'Eco-friendly bamboo wall clock', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 102, name: 'Organic Cotton Diaper', price: 299, rating: 4.5, description: 'Reusable organic cotton diaper', image: 'https://images.unsplash.com/photo-1599487489922-398c8e2b7e3c' },
                { id: 103, name: 'Eco-Friendly Perfume', price: 799, rating: 4.4, description: 'Natural perfume in recyclable bottle', image: 'https://images.unsplash.com/photo-1591123120675-6f7f1aae0e5b' },
                { id: 104, name: 'Bamboo Bookshelf', price: 1999, rating: 4.6, description: 'Eco-friendly bamboo bookshelf', image: 'https://images.unsplash.com/photo-1598960994965-8c24d23f7b29' },
                { id: 105, name: 'Organic Cotton Baby Blanket', price: 999, rating: 4.5, description: 'Soft organic cotton baby blanket', image: 'https://images.unsplash.com/photo-1596560548464-f0100067ec56' }
            ];
            
            productGrid.innerHTML = '';
            const displayProducts = filteredProducts || products;
            
            if (displayProducts.length === 0) {
                productGrid.innerHTML = '<p class="no-results">No products found.</p>';
                return;
            }
            
            displayProducts.forEach(product => {
                const card = document.createElement('div');
                card.className = 'product-card';
                card.innerHTML = `
                    <img src="${product.image}" alt="${product.name}" class="product-img" loading="lazy" width="300" height="300">
                    <div class="product-info">
                        <h3 class="product-title">${product.name}</h3>
                        <p>${product.description}</p>
                        <p class="product-price">₹${product.price.toFixed(2)}</p>
                        <p class="product-rating">${'★'.repeat(Math.floor(product.rating))} ${product.rating.toFixed(1)}</p>
                        <button class="btn add-to-cart" data-id="${product.id}">Add to Cart</button>
                    </div>
                `;
                productGrid.appendChild(card);
            });
            
            return products; // Return products for use in other functions
        }
        
        function setupCart() {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            const cartCount = document.querySelector('.cart-count');
            const cartModal = document.getElementById('cart-modal');
            const cartItems = document.getElementById('cart-items');
            const cartTotal = document.getElementById('cart-total');
            const cartButton = document.querySelector('.cart-button');
            const closeModal = document.querySelector('.close-modal');
            const products = loadProducts(); // Get products array
            
            function updateCart() {
                const count = cart.reduce((total, item) => total + item.quantity, 0);
                cartCount.textContent = count;
                
                cartItems.innerHTML = '';
                let totalPrice = 0;
                
                if (cart.length === 0) {
                    cartItems.innerHTML = '<p class="cart-empty">Your cart is empty.</p>';
                    cartTotal.textContent = '';
                } else {
                    cart.forEach(item => {
                        const product = products.find(p => p.id === item.id);
                        if (product) {
                            const itemTotal = product.price * item.quantity;
                            totalPrice += itemTotal;
                            const cartItem = document.createElement('div');
                            cartItem.className = 'cart-item';
                            cartItem.innerHTML = `
                                <span>${product.name} (x${item.quantity})</span>
                                <span>₹${itemTotal.toFixed(2)}</span>
                                <button class="remove-from-cart" data-id="${item.id}" aria-label="Remove ${product.name} from cart">Remove</button>
                            `;
                            cartItems.appendChild(cartItem);
                        }
                    });
                    cartTotal.textContent = `Total: ₹${totalPrice.toFixed(2)}`;
                }
            }
            
            cartButton.addEventListener('click', () => {
                cartModal.style.display = 'flex';
                cartModal.setAttribute('aria-hidden', 'false');
                updateCart();
                cartModal.querySelector('.close-modal').focus();
            });
            
            closeModal.addEventListener('click', () => {
                cartModal.style.display = 'none';
                cartModal.setAttribute('aria-hidden', 'true');
            });
            
            // Close modal on Esc key
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && cartModal.style.display === 'flex') {
                    cartModal.style.display = 'none';
                    cartModal.setAttribute('aria-hidden', 'true');
                }
            });
            
            document.addEventListener('click', (e) => {
                if (e.target.classList.contains('add-to-cart')) {
                    const productId = parseInt(e.target.dataset.id);
                    const existingItem = cart.find(item => item.id === productId);
                    
                    if (existingItem) {
                        existingItem.quantity += 1;
                    } else {
                        cart.push({ id: productId, quantity: 1 });
                    }
                    
                    localStorage.setItem('cart', JSON.stringify(cart));
                    updateCart();
                    
                    e.target.textContent = 'Added!';
                    setTimeout(() => {
                        e.target.textContent = 'Add to Cart';
                    }, 1500);
                }
                
                if (e.target.classList.contains('remove-from-cart')) {
                    const productId = parseInt(e.target.dataset.id);
                    cart = cart.filter(item => item.id !== productId);
                    localStorage.setItem('cart', JSON.stringify(cart));
                    updateCart();
                }
            });
            
            updateCart();
        }
        
        function setupSearch() {
            const searchInput = document.getElementById('search-input');
            const searchButton = document.querySelector('.search-button');
            const clearSearch = document.querySelector('.clear-search');
            const products = loadProducts(); // Get products array
            
            function performSearch() {
                const query = searchInput.value.trim().toLowerCase();
                if (query === '') {
                    loadProducts();
                    clearSearch.style.display = 'none';
                    return;
                }
                
                const filteredProducts = products.filter(product =>
                    product.name.toLowerCase().includes(query) ||
                    product.description.toLowerCase().includes(query)
                );
                
                loadProducts(filteredProducts);
                clearSearch.style.display = 'inline-block';
            }
            
            searchButton.addEventListener('click', performSearch);
            
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    performSearch();
                }
            });
            
            clearSearch.addEventListener('click', () => {
                searchInput.value = '';
                loadProducts();
                clearSearch.style.display = 'none';
            });
        }
        
        function registerServiceWorker() {
            if ('serviceWorker' in navigator) {
                window.addEventListener('load', () => {
                    navigator.serviceWorker.register('/sw.js').then(registration => {
                        console.log('ServiceWorker registered');
                    }).catch(err => {
                        console.log('ServiceWorker registration failed: ', err);
                    });
                });
            }
        }
        
        document.write('<noscript><style>body>*{display:none;} body:after{content:"JavaScript is required for this site";display:block;padding:2rem;text-align:center;}</style></noscript>');
