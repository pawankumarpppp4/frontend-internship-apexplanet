// Section Navigation
function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');
}

// To-Do List with Local Storage
let todos = JSON.parse(localStorage.getItem('todos')) || [];

function saveTodos() {
    localStorage.setItem('todos', JSON.stringify(todos));
}

function renderTodos() {
    const todoItemsDiv = document.getElementById('todo-items');
    todoItemsDiv.innerHTML = '';
    todos.forEach((todo, index) => {
        const todoDiv = document.createElement('div');
        todoDiv.className = 'todo-item' + (todo.minimized ? ' minimized' : '');
        todoDiv.innerHTML = `
            <span>${todo.minimized ? 'Task (Minimized)' : todo.text}</span>
            <div>
                <button onclick="toggleMinimize(${index})">${todo.minimized ? 'Expand' : 'Minimize'}</button>
                <button onclick="removeTodo(${index})">Remove</button>
            </div>
        `;
        todoItemsDiv.appendChild(todoDiv);
    });
}

function addTodo() {
    const input = document.getElementById('todo-input');
    const text = input.value.trim();
    if (text) {
        todos.push({ text, minimized: false });
        input.value = '';
        saveTodos();
        renderTodos();
    }
}

function toggleMinimize(index) {
    todos[index].minimized = !todos[index].minimized;
    saveTodos();
    renderTodos();
}

function removeTodo(index) {
    todos.splice(index, 1);
    saveTodos();
    renderTodos();
}

// Cart Products with Categories and Ratings
const products = [
    { name: 'Leather Jacket', price: 99.99, image: 'https://images.unsplash.com/photo-1551488831-00ddcb6c0a5a', category: 'Clothing', rating: 4.5 },
    { name: 'Running Shoes', price: 59.99, image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff', category: 'Fitness', rating: 4.2 },
    { name: 'Smart Watch', price: 129.99, image: 'https://images.unsplash.com/photo-1523275339254-cc2c2650a5ee', category: 'Electronics', rating: 4.8 },
    { name: 'Wireless Headphones', price: 79.99, image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e', category: 'Electronics', rating: 4.3 },
    { name: 'Backpack', price: 39.99, image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62', category: 'Accessories', rating: 4.0 },
    { name: 'Sunglasses', price: 29.99, image: 'https://images.unsplash.com/photo-1572635196237-14b3f281503f', category: 'Accessories', rating: 4.1 },
    { name: 'Coffee Maker', price: 89.99, image: 'https://images.unsplash.com/photo-1511381463-3a5f3d4f3e7a', category: 'Home', rating: 4.7 },
    { name: 'Desk Lamp', price: 34.99, image: 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15', category: 'Home', rating: 4.4 },
    { name: 'Gaming Mouse', price: 49.99, image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46', category: 'Electronics', rating: 4.6 },
    { name: 'Yoga Mat', price: 24.99, image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c', category: 'Fitness', rating: 4.2 },
    { name: 'Electric Kettle', price: 44.99, image: 'https://images.unsplash.com/photo-1581147036182-33a0f48d55a8', category: 'Home', rating: 4.5 },
    { name: 'Bluetooth Speaker', price: 69.99, image: 'https://images.unsplash.com/photo-1612206196912-7b9939d2a0dd', category: 'Electronics', rating: 4.3 },
    { name: 'Denim Jeans', price: 54.99, image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246', category: 'Clothing', rating: 4.1 },
    { name: 'Wrist Watch', price: 89.99, image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314', category: 'Accessories', rating: 4.7 },
    { name: 'Portable Charger', price: 29.99, image: 'https://images.unsplash.com/photo-1600080979851-011e2d47b587', category: 'Electronics', rating: 4.0 },
    { name: 'Winter Scarf', price: 19.99, image: 'https://images.unsplash.com/photo-1605487903301-195be682aaff', category: 'Clothing', rating: 4.2 },
    { name: 'Graphic T-Shirt', price: 24.99, image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab', category: 'Clothing', rating: 4.0 },
    { name: 'Laptop Stand', price: 39.99, image: 'https://images.unsplash.com/photo-1614624533125-41d2524295a9', category: 'Electronics', rating: 4.5 },
    { name: 'Water Bottle', price: 14.99, image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8', category: 'Fitness', rating: 4.1 },
    { name: 'Fitness Tracker', price: 59.99, image: 'https://images.unsplash.com/photo-1576243345591-6f14403986e5', category: 'Fitness', rating: 4.6 },
    { name: 'Kitchen Mixer', price: 149.99, image: 'https://images.unsplash.com/photo-1581599439158-2b1c9e1a9a7b', category: 'Home', rating: 4.8 },
    { name: 'Hiking Boots', price: 79.99, image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b', category: 'Fitness', rating: 4.4 },
    { name: 'Camera Tripod', price: 49.99, image: 'https://images.unsplash.com/photo-1519638399536-2f2a3b979d0a', category: 'Electronics', rating: 4.2 },
    { name: 'Office Chair', price: 199.99, image: 'https://images.unsplash.com/photo-1505842466681-7f track-5e6a8', category: 'Home', rating: 4.9 },
    { name: 'Wall Art Print', price: 29.99, image: 'https://images.unsplash.com/photo-1513161455079-2f2a3b979d0a', category: 'Home', rating: 4.3 }
];

let filteredProducts = [...products];

function applyFilters() {
    const categoryFilter = document.getElementById('category-filter').value;
    const priceFilter = document.getElementById('price-filter').value;
    const sortRating = document.getElementById('sort-rating').value;

    // Filter by category
    filteredProducts = products.filter(product => {
        if (categoryFilter && product.category !== categoryFilter) return false;
        return true;
    });

    // Filter by price
    filteredProducts = filteredProducts.filter(product => {
        if (!priceFilter) return true;
        if (priceFilter === '0-30') return product.price <= 30;
        if (priceFilter === '30-60') return product.price > 30 && product.price <= 60;
        if (priceFilter === '60-100') return product.price > 60 && product.price <= 100;
        if (priceFilter === '100+') return product.price > 100;
        return true;
    });

    // Sort by rating
    if (sortRating) {
        filteredProducts.sort((a, b) => {
            if (sortRating === 'high-to-low') return b.rating - a.rating;
            if (sortRating === 'low-to-high') return a.rating - b.rating;
            return 0;
        });
    }

    renderProducts();
}

function resetFilters() {
    document.getElementById('category-filter').value = '';
    document.getElementById('price-filter').value = '';
    document.getElementById('sort-rating').value = '';
    filteredProducts = [...products];
    renderProducts();
}

function renderProducts() {
    const productListDiv = document.getElementById('product-list');
    productListDiv.innerHTML = '';
    filteredProducts.forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.className = 'product';
        productDiv.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <div class="product-details">
                <h3>${product.name}</h3>
                <p>Price: $${product.price}</p>
                <p>Rating: ${product.rating}/5</p>
            </div>
        `;
        productListDiv.appendChild(productDiv);
    });
}

// Initial Render
renderTodos();
renderProducts();