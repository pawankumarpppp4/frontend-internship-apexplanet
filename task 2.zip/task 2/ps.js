function showSlide(slideName) {
  const slides = document.querySelectorAll('.slides-container');
  slides.forEach(slide => slide.style.display = 'none');

  if (slideName === 'home') {
    document.getElementById('homeSlide').style.display = 'block';
  } else if (slideName === 'game') {
    document.getElementById('gameSlide').style.display = 'block';
  } else if (slideName === 'contact') {
    document.getElementById('contactSlide').style.display = 'block';
  } else if (slideName === 'about') {
    document.getElementById('aboutSlide').style.display = 'block';
  }
}

showSlide('home');

function addTask() {
  const taskInput = document.getElementById("taskInput");
  const taskText = taskInput.value.trim();

  if (taskText === "") {
    alert("Please enter a task.");
    return;
  }

  const li = document.createElement("li");
  li.textContent = taskText;

  const removeBtn = document.createElement("button");
  removeBtn.textContent = "Remove";
  removeBtn.className = "remove-btn";
  removeBtn.onclick = function () {
    li.remove();
  };

  li.appendChild(removeBtn);
  document.getElementById("taskList").appendChild(li);
  taskInput.value = "";
}

document.getElementById("contactForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!name || !email || !message) {
    alert("All fields are required.");
  } else if (!emailRegex.test(email)) {
    alert("Please enter a valid email.");
  } else {
    alert("Form submitted successfully!");
    this.reset();
  }
});
