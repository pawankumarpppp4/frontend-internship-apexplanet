function fetchJoke() {
  fetch("https://official-joke-api.appspot.com/random_joke")
    .then(response => response.json())
    .then(data => {
      document.getElementById("setup").innerText = data.setup;
      document.getElementById("punchline").innerText = data.punchline;

      // Generate a random image using a new seed
      const randomSeed = Math.floor(Math.random() * 1000);
      const imageUrl = `https://picsum.photos/seed/${randomSeed}/400/300`;
      document.getElementById("joke-img").src = imageUrl;
    })
    .catch(error => {
      document.getElementById("setup").innerText = "Failed to fetch joke.";
      document.getElementById("punchline").innerText = "";
      console.error("Error:", error);
    });
}
let quizData = [];
let currentQuestionIndex = 0;
let score = 0;

// Fetch questions from Open Trivia DB API
function fetchQuizData() {
  fetch("https://opentdb.com/api.php?amount=5&category=18&type=multiple")
    .then(response => response.json())
    .then(data => {
      quizData = data.results;
      loadQuestion();
    })
    .catch(err => {
      document.getElementById("quiz-question").innerText = "Failed to load quiz questions.";
      console.error("Quiz Error:", err);
    });
}

function decodeHTML(html) {
  let txt = document.createElement("textarea");
  txt.innerHTML = html;
  return txt.value;
}

function loadQuestion() {
  const question = quizData[currentQuestionIndex];
  const options = [...question.incorrect_answers];
  options.splice(Math.floor(Math.random() * 4), 0, question.correct_answer); // insert correct answer randomly

  document.getElementById("quiz-question").innerText = decodeHTML(question.question);
  const quizOptions = document.getElementById("quiz-options");
  quizOptions.innerHTML = "";

  options.forEach((option, index) => {
    const label = document.createElement("label");
    label.innerHTML = `<input type="radio" name="option" value="${option}" /> ${decodeHTML(option)}`;
    quizOptions.appendChild(label);
  });

  document.getElementById("quiz-feedback").innerText = "";
  document.getElementById("next-question").style.display = "none";
  document.getElementById("submit-answer").style.display = "inline";
}

document.getElementById("submit-answer").addEventListener("click", () => {
  const selected = document.querySelector('input[name="option"]:checked');
  const feedback = document.getElementById("quiz-feedback");

  if (!selected) {
    feedback.innerText = "⚠️ Please select an option!";
    feedback.style.color = "orange";
    return;
  }

  const answer = selected.value;
  const correct = quizData[currentQuestionIndex].correct_answer;

  if (answer === correct) {
    feedback.innerText = "✅ Correct!";
    feedback.style.color = "green";
    score++;
  } else {
    feedback.innerText = `❌ Wrong! Correct answer: ${decodeHTML(correct)}`;
    feedback.style.color = "red";
  }

  document.getElementById("submit-answer").style.display = "none";
  document.getElementById("next-question").style.display = "inline";
});

document.getElementById("next-question").addEventListener("click", () => {
  currentQuestionIndex++;
  if (currentQuestionIndex < quizData.length) {
    loadQuestion();
  } else {
    showScore();
  }
});

function showScore() {
  document.getElementById("quiz-container").innerHTML = `<h3>Your Score: ${score} / ${quizData.length}</h3>`;
}

fetchQuizData(); // Start the quiz
